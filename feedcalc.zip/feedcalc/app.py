from flask import Flask
from flask import render_template, request, redirect, url_for, flash
from flask_login import current_user, login_user, logout_user, LoginManager
from flask_login import login_required
from flask_migrate import Migrate

from werkzeug.security import generate_password_hash, check_password_hash
#motor
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)

from .models import  db, Users, Recipe
from .schema import RecipeSchema, ProfileSchema, ma

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite'
app.config['SECRET_KEY'] = 'x.@&F{jW3*}$8&pN+p#ot>n&QS$?'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
migrate = Migrate(app, db)
ma.init_app(app)
# setting flask login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = '.login'


@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(int(user_id))


# @app.route('/')
# def easyindex():
#   return render_template('easyindex.html')

@app.route('/')
def easyindex():
    return render_template('index.html')

# @app.route('/profile')
# @login_required
# def profile():
    # return render_template('profile.html', username=current_user.username)


@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html', username=current_user.username,
                                         date_joined=current_user.date_joined)


    
@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def login_post():
    # login code goes here
    email = request.form.get('email')
    password = request.form.get('password')
    remember = True if request.form.get('remember') else False

    user = Users.query.filter_by(email=email).first()

    # check if the user actually exists
    # take the user-supplied password, hash it, and compare it to the hashed password in the database
    if not user or not check_password_hash(user.password, password):
        flash('Please check your login details and try again.')
        return redirect(url_for('login'))  # if the user doesn't exist or password is wrong, reload the page
    login_user(user, remember=remember)
    return redirect('/farmer_dashboard')



@app.route('/signup')
def signup():
    return render_template('signup.html')

# @app.route('/coops')
# def easyindex():
#     return render_template('coops.html')

@app.route('/signup', methods=['POST'])
def signup_post():
    # code to validate and add user to database goes here
    email = request.form.get('email')
    name = request.form.get('name')
    password = request.form.get('password')
  
    user = Users.query.filter_by(
        email=email).first()  # if this returns a user, then the email already exists in database

    if user:  # if a user is found, we want to redirect back to signup page so user can try again
        flash('Email address already exists')
        return redirect('/signup')

    # creating a new user with the form data. Hash the password so the plaintext version isn't saved.
    new_user = Users(email=email, username=name, password=generate_password_hash(password, method='sha256'))
    flash('You have been added succesfully')
    # add the new user to the database
    db.session.add(new_user)
    db.session.commit()
    return redirect('/login')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')


@app.route('/layers')
@login_required
def layers():
    return render_template('layers.html')

@app.route('/myprofile')
@login_required
def my_profile():
    return render_template('myprofile.html', username=current_user.username)

@app.route('/layers_all')
@login_required
def layersall():
    return render_template('layers_all.html')

@app.route('/farmer_dashboard')
@login_required
def farmer_db():
    return render_template('farmer_dashboard.html', username=current_user.username)

@app.route('/calc_result', methods=['POST', 'GET'])
@login_required
def calc_result():  # ~ Route to send calculator form input
    error = ''
    result = ''
    wmaize = ''
    soya = ''
    fishm = ''
    maizeb = ''
    limes = ''

    amount_input = request.form['total']
    feed = request.form['feed']
    input1 = float(amount_input)

    if feed == "layers1":
        wmaize = (0.5 * input1)
        soya = (0.2 * input1)
        fishm = (0.1 * input1)
        maizeb = (0.1 * input1)
        limes = (0.10 * input1)
        result = wmaize + soya + fishm + maizeb + limes
        print(result)
        # saving the results into database
        recipe_instance = Recipe(feed=feed, amount_entered=amount_input, result=result, user_id=current_user.id)
        db.session.add(recipe_instance)
        db.session.commit()

        return render_template(
            'layers1.html',
            input1=input1, feed=feed,
            wmaize=wmaize,
            soya=soya,
            maizeb=maizeb,
            fishm=fishm,
            limes=limes,
            result=result)
    
            
@app.route('/demo')
def demo():
    return render_template('demo.html')

#@app.route('/motors')
#def motors():
    #return render_template('demo_result.html')

  
@app.route('/demo_calc', methods=['POST', 'GET'])
def demo_calc():
    #ufa='' #feed A
    #soya=''#feed B
    
    amount_input=request.form['total']
    feed=request.form['feed']
    input1=float(amount_input)
    if feed =="demo":
        ufa = (0.9*input1)
        soya = (0.1*input1)

    motor1 = [7,11,13,15] #first motor pins defined
    #motor2 = [19,8,12,21]
    
    for pin in motor1:
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, 0)
    halfstep_seq = [
      [1,0,0,0],
      [1,1,0,0],
      [0,1,0,0],
      [0,1,1,0],
      [0,0,1,0],
      [0,0,1,1],
      [0,0,0,1],
      [1,0,0,1]
    ]
    
    for i in range(int(512*ufa)): #rotating for feed A
      for halfstep in range(8):
        for pin in range(4):
          GPIO.output(motor1[pin], halfstep_seq[halfstep][pin])
        time.sleep(0.01)
        
#     for pin in motor2:
#         GPIO.setup(pin, GPIO.OUT)
#         GPIO.output(pin, 0)
#     halfstep_seq = [
#       [1,0,0,0],
#       [1,1,0,0],
#       [0,1,0,0],
#       [0,1,1,0],
#       [0,0,1,0],
#       [0,0,1,1],
#       [0,0,0,1],
#       [1,0,0,1]
#     ]
#        
#     for i in range(int(512*soya)): #rotating for feed A
#       for halfstep in range(8):
#         for pin in range(4):
#           GPIO.output(motor2[pin], halfstep_seq[halfstep][pin])
#         time.sleep(0.001) 
#     GPIO.cleanup()
    
    return render_template(
            'demo_result.html',
            input1=input1, feed=feed,
            ufa=ufa, soya=soya)
        
   
@app.route('/user/results', methods=['POST', 'GET'])
@login_required
def get_past_calc_result():
    recipe_schema = RecipeSchema(many=True)

    all_users_recipe = Recipe.query.filter_by(user_id=current_user.id).all()
    recipe_data = recipe_schema.dump(all_users_recipe)
    
    return render_template(
        'layers_all.html',
        data=recipe_data
    )

@app.route('/user/myprofile', methods=['POST', 'GET'])
@login_required
def viewmyprofile():
       myprofile_schema = ProfileSchema()
        
       all_users_myprofile = Users.query.filter_by(user_id=current_user.id).all()
       users_data = myprofile_schema.dump(all_users)
        
       return render_template('viewprofile.html')
    
def create_app():
    db.init_app(app)
    Migrate(app, db)
    return app


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=80)
