from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import func
from datetime import datetime, timedelta
db = SQLAlchemy()


# the model schema for the database
class Recipe(db.Model):
    __tablename__ = 'recipe'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    feed = db.Column(db.String(100), nullable=False)
    amount_entered = db.Column(db.Integer, nullable=False)
    result = db.Column(db.Integer, nullable=False)
    user_id = db.Column(db.Integer,
                        db.ForeignKey('users.id', ondelete='CASCADE'),
                        nullable=False)


class Users(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(1000), nullable=False)
    password = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True)
    date_added = db.Column(db.DateTime, default=datetime.utcnow)
    recipe_object = db.relationship('Recipe', backref='users', lazy=True, uselist=True,
                                    cascade="all,delete")
    # date_joined = db.Column(db.DateTime(timezone=True),
                           # server_default=func.now())
    
    def __repr__(self):
        return '<Name %r>' % self.username
#     coops_object = db.relationship('Coops', backref='users', lazy=True, uselist=True,
#                                     cascade="all,delete")

# class Coops(db.Model):
#     __tablename__= 'coops'
#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     name = db.Column(db.String(1000), nullable=False)
#     age = db.Column(db.Integer, nullable=False)
#     breed = db.Column(db.String(1000), nullable=False)
#     number = db.Column(db.Integer, nullable=False)
# #     user_id = db.Column(db.Integer,
# #                         db.ForeignKey('users.id', ondelete='CASCADE'),
# #                         nullable=False)
#     
#     def __repr__(self):
#         return f'<Coops {self.name}>'
    
